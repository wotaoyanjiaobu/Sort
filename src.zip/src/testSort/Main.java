package testSort;
import java.util.Arrays;
import BubbleSort.*;
import InsertSort.InsertSort;
import MergeSort.MergeSort;
import QuickSort.QuickSort;
import ShellSort.ShellSort;

public class Main {
	public static void main(String[] args){
		int[] test = new int[10000];
		Arrays.fill(test, 0);
		for(int i = 0; i < test.length; i++)
			test[i] = (int)(Math.random() * 10000);
		
		//BubbleSort sort = new BubbleSort();
		//InsertSort sort = new InsertSort();
		//ShellSort sort = new ShellSort();
		QuickSort sort = new QuickSort();
		//MergeSort sort = new MergeSort();
		long start = System.currentTimeMillis();
		sort.sort(test);
		long end = System.currentTimeMillis();
		
		System.out.println("Time is " + (end - start));
		
		PrintEle ele = new PrintEle();
		//ele.printEle(test);
		//String osName = System.getProperty("user.name");
		//System.out.println(osName);
	}
}
