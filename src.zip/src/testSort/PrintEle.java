package testSort;

public class PrintEle {
	public void printEle(int[] arr){
		for(int x : arr)
			System.out.println(x);
	}
}
