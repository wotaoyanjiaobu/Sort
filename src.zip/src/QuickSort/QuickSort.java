package QuickSort;

public class QuickSort {
	public void swap(int[] arr, int i, int j){
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
	
	public int getPos(int[] arr, int left, int right){
		int key = arr[left];
		int keyPos = left;
		while(left < right){
			while(left < right && arr[right] >= key)
				right--;
			while(left < right && arr[left] <= key)
				left++;
			swap(arr, left, right);
		}
		swap(arr, keyPos, left);
		return left;
	}
	
	public void quickSort(int[] arr, int left, int right){
		if(left >= right)
			return;
		int temp = getPos(arr, left, right);
		quickSort(arr, left, temp-1);
		quickSort(arr, temp+1, right);
	}
	
	public void sort(int[] arr){
		if(arr == null || arr.length == 0)
			return;
		quickSort(arr, 0, arr.length-1);
	}
}
