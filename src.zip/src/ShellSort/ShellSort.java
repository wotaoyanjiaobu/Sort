package ShellSort;

public class ShellSort {
	public void shellInsert(int[] arr, int d){
		for(int i = d; i < arr.length; i++){
			int j = i;
			int target = arr[i];
			
			while(j-d >= 0 && arr[j-d] > target){
				arr[j] = arr[j-d];
				j -= d;
			}
			if(j != i)
				arr[j] = target;
		}
	}
	
	public void sort(int[] arr){
		if(arr == null || arr.length == 0)
			return;
		int d = arr.length;
		while(d > 0){
			shellInsert(arr, d);
			d /= 2;
		}
	}
}
