package InsertSort;

public class InsertSort {
	public void sort(int[] arr){
		if(arr == null || arr.length == 0)
			return ;
		
		for(int i = 1; i < arr.length; i++){
			int target = arr[i];
			
			int j = i;
			while(j > 0 && arr[j-1] > target)
				arr[j] = arr[--j];
			
			arr[j] = target;
		}
	}
}
